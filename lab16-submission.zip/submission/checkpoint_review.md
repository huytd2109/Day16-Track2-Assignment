# Kiểm tra bài LAB 16 — ngày 04/10/2026 (UTC+7)

Đối chiếu với Phần 6 của `README_aws.md`. Code, JSON và log có nội dung nhất quán; bộ nộp còn thiếu ảnh Billing đúng kỳ. Hai ảnh terminal bổ sung là ảnh xem lại log thật trên máy local sau cleanup, không phải ảnh chụp trực tiếp trong lần chạy EC2.

| Deliverable | Kết quả kiểm tra | Bằng chứng / việc còn cần |
|---|---|---|
| 1. Screenshot benchmark | Đã bổ sung ảnh xem lại toàn bộ output | [benchmark_terminal.png](screenshots/benchmark_terminal.png), nguồn `benchmark_output.txt`; lệnh chạy gốc và exit code 0 trong `evidence/run_manifest.json`. Nếu yêu cầu ảnh trực tiếp lần chạy gốc thì ảnh xem lại chưa đáp ứng hoàn toàn. |
| 2. JSON metrics | Đạt kiểm tra file | `benchmark_result.json` có đủ 10 metrics; nội dung khớp JSON trong output, throughput và F1 khớp công thức. |
| 3. Screenshot CPU/RAM/Network | Đã bổ sung ảnh xem lại log | [resource_usage.png](screenshots/resource_usage.png) hiển thị đầy đủ `top`, `free -h`, `ip -s link`. Mẫu thu trong benchmark, chưa chứng minh peak CPU/RAM khi fit. |
| 4. Screenshot Billing | Chưa đạt phạm vi ngày lab | [billing.png](screenshots/billing.png) hiển thị $0.00, 0 dịch vụ, tháng 4–9/2026. Cần chọn 02/10/2026 (hoặc khoảng bao gồm ngày này), Group by Service và chụp cả bộ lọc/chi phí EC2, NAT nếu có. |
| 5. Source Terraform nén | Đã đóng gói | `lab16-submission.zip` chứa `submission/infra/`: 7 file source/lock giống thư mục Terraform thực chạy. Không chứa credentials, SSH key, state, tfvars, dataset hoặc `.terraform/`. |
| 6. Báo cáo 5–10 dòng | Đạt hình thức và đối chiếu số liệu | `report.md` có 8 dòng; ghi đúng máy thực đo t3.small và nêu giới hạn bằng chứng. |

## Kết quả kỹ thuật

- Cú pháp Python (`ast.parse`) và shell (`bash -n`) hợp lệ. Terraform `validate -json` thành công: 0 lỗi, 0 cảnh báo. Validate cần chạy ngoài sandbox để provider tạo socket cục bộ; không apply/destroy hạ tầng.
- SHA-256 `benchmark.py` và `benchmark_result.json` khớp bản đã xác minh trên VM trong `evidence/run_manifest.json`; log gốc không bị sửa. Danh sách hash hiện tại ở `evidence/artifact_sha256.json`.
- Split 170883/56962/56962 có tổng 284807 dòng; seed 16; tách stratify 60/20/20. Early stopping chỉ dùng validation; AUC lấy xác suất, các metrics phân loại dùng ngưỡng 0.5. Accuracy cao cần đọc cùng F1/Recall vì mất cân bằng lớp.
- Inference có warm-up, dùng median 50 lần cho 1 dòng và 10 lần cho batch 1000 dòng; cắt DataFrame ngoài timer. Throughput = 1000 / thời gian batch (giây).
- Không chạy lại training trong lần kiểm tra này: môi trường local thiếu dataset và thư viện ML. Các kết quả EC2 được kiểm tra từ artifact đã lưu, không tạo kết quả đo mới.
- `terraform fmt -check` báo khác biệt căn lề ở `main.tf` và `outputs.tf`; đây là vấn đề định dạng. Giữ nguyên snapshot source thực chạy để bảo toàn hash trong bộ bằng chứng.

## Giới hạn và cách hoàn thiện

Máy đã đo là **t3.small**, khác cấu hình mặc định **t3.medium** trong README. Báo cáo ghi rõ sự khác biệt. Để tái tạo máy đã đo, dùng `-var=cpu_instance_type=t3.small`; tạo SSH key mới và thay CIDR SSH `/32` trong `infra/main.tf` bằng IP của người chạy. Đây chỉ là hướng dẫn tái tạo, không có hạ tầng nào được tạo trong lần kiểm tra này.

Lỗi API Billing ngày 02/10 được giữ nguyên ở `evidence/billing_check.json`. Ảnh Billing bổ sung không chứng minh chi phí ngày lab bằng 0, cũng không đủ để kết luận Billing cập nhật chậm. Không cần tạo lại VM để xem Billing; có thể chụp Console bằng tài khoản có quyền phù hợp và thay ảnh hiện tại bằng ảnh đúng kỳ.

Cleanup được người dùng xác nhận, state local hiện có 0 tài nguyên và 0 outputs, khớp `evidence/cleanup_result.json`. Không có log `Destroy complete!` hoặc kiểm kê AWS độc lập trong bộ bằng chứng này.

CP3 đạt kiểm tra artifact; CP4/CP5 còn phụ thuộc ảnh Billing đúng ngày và việc giảng viên chấp nhận ảnh xem lại log. Bộ ZIP đã cập nhật để chứa ảnh và báo cáo mới. Không commit, push hoặc nộp bài trong lần kiểm tra này.
